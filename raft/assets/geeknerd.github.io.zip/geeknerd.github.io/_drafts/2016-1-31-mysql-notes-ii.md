---
layout: post
title: MySQL Syntax Notes(II)
date: 2016-02-08
modified: 2016-02-08
comments: true
pinned: true
tags: [MySQL]
---

* ```IFNULL``` function returns first argument if it is **NOT NULL**, otherwise, it returns the second argument. 